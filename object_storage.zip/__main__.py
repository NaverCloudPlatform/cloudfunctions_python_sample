import boto3

def main(args):
    service_name = 's3'
    endpoint_url = 'https://kr.objectstorage.ncloud.com'
    region_name = 'kr-standard'
    access_key = 'UserAccessKey'
    secret_key = 'UserSecretKey'

    s3 = boto3.client(service_name, endpoint_url=endpoint_url, aws_access_key_id=access_key,aws_secret_access_key=secret_key)
    response = s3.list_buckets()
    return {"payload": response}
